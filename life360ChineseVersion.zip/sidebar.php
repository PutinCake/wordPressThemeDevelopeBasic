<div class="col-md-3 pdfixr">
				<div class="widget-area">
					<?php if(is_active_sidebar('sidebar-1')) : ?> 
						<?php dynamic_sidebar('sidebar-1') ; ?>
						<?php else: ?>
							No Sidebar
					<?php endif; ?>
				</div>
			</div>